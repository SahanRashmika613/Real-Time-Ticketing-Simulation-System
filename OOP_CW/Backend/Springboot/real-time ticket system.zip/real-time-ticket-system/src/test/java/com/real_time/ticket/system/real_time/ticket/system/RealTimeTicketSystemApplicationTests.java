package com.real_time.ticket.system.real_time.ticket.system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RealTimeTicketSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
