package com.real_time.ticket.system.real_time.ticket.system;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RealTimeTicketSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(RealTimeTicketSystemApplication.class, args);
	}

}
